package triblab

import (
	"trib"
)

func NewBinClient(backs []string) trib.BinStorage {
	panic("todo")
}

func ServeKeeper(kc *trib.KeeperConfig) error {
	panic("todo")
}

func NewFront(s trib.BinStorage) trib.Server {
	panic("todo")
}
